import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class employeesListServices{
    constructor(private http:Http){}

    get(employees){
        return this.http.get(employees)
        .map(response=>{
            return response.json().employees;
        });
    }

    add(employee){
    return this.http.post('employees',employee)
    .map(response=>{});
    }

    delete(employee){
    return this.http.delete(`employees/${employee.id}`)
    .map(response=>{});
    }
}