import { Component, OnInit } from '@angular/core';
import {employeesListServices} from 'app/employeeslist.services';
import {MdDialog} from '@angular/material';
import {PopupComponent} from 'app/popup/popup.component';
import {Router} from '@angular/router';

@Component({
  selector: 'emp-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private EmployeesListServices:employeesListServices,
  private router:Router,
  public dialog:MdDialog) { }

  employees;
  buttonStatus=null;
  deleteStatus=null;
  tempDeleteData;
  selectedId;

  ngOnInit() {
    this.EmployeesListServices.get("employees").subscribe(employees=>this.employees=employees);
  }

  onClicked(employee){
    this.buttonStatus=1;
    this.tempDeleteData=employee;
  }

  onColorClicked(employeeId){
    this.selectedId=employeeId;
  }

  onAddClicked(){
    this.buttonStatus=null;
    this.selectedId=null;
    this.router.navigate(['add']);
  }

  openDialog(){
    this.dialog.open(PopupComponent);
  }

  onDeleteClicked(){
    this.deleteStatus=1;
  }

  onConfrimationNo(){
    this.deleteStatus=null;
  }

  onConfrimationYes(){
    this.deleteStatus=null;
    this.EmployeesListServices.delete(this.tempDeleteData)
    .subscribe(()=>{
       this.EmployeesListServices.get("employees").subscribe(employees=>{
       this.employees=employees;
       this.buttonStatus=null;
    });
  });
  
    
  }
}
