import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()
export class sharedServices{
    constructor(){}
    tempValue=null;

    get(){
        return this.tempValue;
    }

    add(flag){
        this.tempValue=flag;
    }
}